using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;

namespace DraggableWindows
{
    [BepInPlugin("noone.draggablewindows", "Draggable Windows", "1.0.0")]
    public class Plugin : BaseUnityPlugin
    {
        public static Plugin Instance { get; private set; }

        // Position configs for each window
        public static ConfigEntry<float> SpellbookPosX;
        public static ConfigEntry<float> SpellbookPosY;
        public static ConfigEntry<float> SkillbookPosX;
        public static ConfigEntry<float> SkillbookPosY;
        public static ConfigEntry<float> InventoryPosX;
        public static ConfigEntry<float> InventoryPosY;
        public static ConfigEntry<float> VendorPosX;
        public static ConfigEntry<float> VendorPosY;
        public static ConfigEntry<float> QuestLogPosX;
        public static ConfigEntry<float> QuestLogPosY;
        public static ConfigEntry<float> LootPosX;
        public static ConfigEntry<float> LootPosY;
        public static ConfigEntry<float> GuildPosX;
        public static ConfigEntry<float> GuildPosY;
        public static ConfigEntry<float> GroupPosX;
        public static ConfigEntry<float> GroupPosY;
        public static ConfigEntry<float> BetterStatsPagePosX;
        public static ConfigEntry<float> BetterStatsPagePosY;
        public static ConfigEntry<float> AuctionHousePosX;
        public static ConfigEntry<float> AuctionHousePosY;
        public static ConfigEntry<float> BankPosX;
        public static ConfigEntry<float> BankPosY;
        public static ConfigEntry<float> VanillaWorldMapPosX;
        public static ConfigEntry<float> VanillaWorldMapPosY;

        private void Awake()
        {
            Instance = this;
            Logger.LogInfo("Draggable Windows: Initializing...");

            // Bind position configs for each window type
            SpellbookPosX = Config.Bind("Spellbook", "PositionX", float.NaN, "Saved X position");
            SpellbookPosY = Config.Bind("Spellbook", "PositionY", float.NaN, "Saved Y position");

            SkillbookPosX = Config.Bind("Skillbook", "PositionX", float.NaN, "Saved X position");
            SkillbookPosY = Config.Bind("Skillbook", "PositionY", float.NaN, "Saved Y position");

            InventoryPosX = Config.Bind("Inventory", "PositionX", float.NaN, "Saved X position");
            InventoryPosY = Config.Bind("Inventory", "PositionY", float.NaN, "Saved Y position");

            VendorPosX = Config.Bind("Vendor", "PositionX", float.NaN, "Saved X position");
            VendorPosY = Config.Bind("Vendor", "PositionY", float.NaN, "Saved Y position");

            QuestLogPosX = Config.Bind("QuestLog", "PositionX", float.NaN, "Saved X position");
            QuestLogPosY = Config.Bind("QuestLog", "PositionY", float.NaN, "Saved Y position");

            LootPosX = Config.Bind("Loot", "PositionX", float.NaN, "Saved X position");
            LootPosY = Config.Bind("Loot", "PositionY", float.NaN, "Saved Y position");

            GuildPosX = Config.Bind("Guild", "PositionX", float.NaN, "Saved X position");
            GuildPosY = Config.Bind("Guild", "PositionY", float.NaN, "Saved Y position");

            GroupPosX = Config.Bind("Group", "PositionX", float.NaN, "Saved X position");
            GroupPosY = Config.Bind("Group", "PositionY", float.NaN, "Saved Y position");

            BetterStatsPagePosX = Config.Bind("BetterStatsPage", "PositionX", float.NaN, "Saved X position");
            BetterStatsPagePosY = Config.Bind("BetterStatsPage", "PositionY", float.NaN, "Saved Y position");

            AuctionHousePosX = Config.Bind("AuctionHouse", "PositionX", float.NaN, "Saved X position");
            AuctionHousePosY = Config.Bind("AuctionHouse", "PositionY", float.NaN, "Saved Y position");

            BankPosX = Config.Bind("Bank", "PositionX", float.NaN, "Saved X position");
            BankPosY = Config.Bind("Bank", "PositionY", float.NaN, "Saved Y position");

            VanillaWorldMapPosX = Config.Bind("VanillaWorldMap", "PositionX", float.NaN, "Saved X position");
            VanillaWorldMapPosY = Config.Bind("VanillaWorldMap", "PositionY", float.NaN, "Saved Y position");

            // Create controller using pattern from other mods
            GameObject controllerGO = new GameObject("DraggableWindowsController");
            controllerGO.transform.SetParent(null);
            controllerGO.hideFlags = HideFlags.HideAndDontSave;
            controllerGO.AddComponent<DraggableWindowsController>();
            Object.DontDestroyOnLoad(controllerGO);

            // Apply Harmony patches
            Harmony harmony = new Harmony("noone.draggablewindows");
            harmony.PatchAll();

            Logger.LogInfo("Draggable Windows: Initialized.");
        }

        public void SaveConfig()
        {
            Config.Save();
        }
    }
}

