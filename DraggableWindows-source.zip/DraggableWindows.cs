using System.Collections.Generic;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace DraggableWindows
{
    /// <summary>
    /// MonoBehaviour controller that manages draggable windows.
    /// </summary>
    public class DraggableWindowsController : MonoBehaviour
    {
        public static DraggableWindowsController Instance { get; private set; }

        // Track which windows we've already set up
        private HashSet<GameObject> initializedWindows = new HashSet<GameObject>();

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            SceneManager.sceneLoaded += OnSceneLoaded;
            Debug.Log("DraggableWindowsController: Initialized");
        }

        private void OnDestroy()
        {
            SceneManager.sceneLoaded -= OnSceneLoaded;
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            // Clear initialized windows on scene change - they may be stale
            initializedWindows.Clear();
        }

        private void Update()
        {
            // Skip menu scenes
            string sceneName = SceneManager.GetActiveScene().name;
            if (sceneName == "Menu" || sceneName == "LoadScene") return;
            if (GameData.PlayerControl == null) return;

            // Check and setup each window type
            TrySetupWindow(GameData.PlayerSpellBook?.Spellbook, "Spellbook",
                Plugin.SpellbookPosX, Plugin.SpellbookPosY);
            TrySetupWindow(GameData.PlayerSkillBook?.Skillbook, "Skillbook",
                Plugin.SkillbookPosX, Plugin.SkillbookPosY);
            TrySetupWindow(GameData.PlayerInv?.InvWindow, "Inventory",
                Plugin.InventoryPosX, Plugin.InventoryPosY);
            TrySetupWindow(GameData.VendorWindow?.WindowParent, "Vendor",
                Plugin.VendorPosX, Plugin.VendorPosY);
            TrySetupWindow(GameData.QuestLog?.QuestWindow, "QuestLog",
                Plugin.QuestLogPosX, Plugin.QuestLogPosY);
            TrySetupWindow(GameData.LootWindow?.WindowParent, "Loot",
                Plugin.LootPosX, Plugin.LootPosY);

            // Guild Manager UI
            TrySetupWindow(GameData.GuildManagerUI?.gameObject, "Guild",
                Plugin.GuildPosX, Plugin.GuildPosY);

            // Group Builder
            TrySetupWindow(GameData.GroupBuilder?.gameObject, "Group",
                Plugin.GroupPosX, Plugin.GroupPosY);

            // Auction House
            TrySetupWindow(GameData.AHUI?.AHWindow, "AuctionHouse",
                Plugin.AuctionHousePosX, Plugin.AuctionHousePosY);

            // Bank
            TrySetupWindow(GameData.BankUI?.BankWindow, "Bank",
                Plugin.BankPosX, Plugin.BankPosY);

            // Vanilla World Map (from menu bar)
            TrySetupWindow(GameData.HKMngr?.Map, "VanillaWorldMap",
                Plugin.VanillaWorldMapPosX, Plugin.VanillaWorldMapPosY);

            // NOTE: Minimap dragging is handled by BetterMinimap mod, not here

            // BetterStatsPage - find by canvas name
            TrySetupBetterStatsPage();
        }

        private void TrySetupBetterStatsPage()
        {
            // Find BetterStatsCanvas which is created by BetterStatsPage mod
            var statsCanvas = GameObject.Find("BetterStatsCanvas");
            if (statsCanvas == null) return;

            var windowPanel = statsCanvas.transform.Find("WindowPanel");
            if (windowPanel == null) return;

            TrySetupWindow(windowPanel.gameObject, "BetterStatsPage",
                Plugin.BetterStatsPagePosX, Plugin.BetterStatsPagePosY);
        }

        private void TrySetupWindow(GameObject window, string windowName,
            ConfigEntry<float> posX, ConfigEntry<float> posY)
        {
            if (window == null) return;
            if (initializedWindows.Contains(window)) return;

            // Add the drag handler component
            var handler = window.GetComponent<WindowDragHandler>();
            if (handler == null)
            {
                handler = window.AddComponent<WindowDragHandler>();
                handler.Initialize(windowName, posX, posY);
                Debug.Log($"DraggableWindows: Setup drag handler for {windowName}");
            }

            initializedWindows.Add(window);
        }

        /// <summary>
        /// Sets up a window where the clickable/draggable area is different from the window being moved.
        /// Used for minimap where we want clicks constrained to the visible circle (Mask) but move the parent (MapPar).
        /// Creates a transparent overlay child to ensure drag events are captured above any existing elements.
        /// </summary>
        private void TrySetupWindowWithSeparateRaycastTarget(GameObject windowToMove, GameObject raycastTarget,
            string windowName, ConfigEntry<float> posX, ConfigEntry<float> posY)
        {
            if (windowToMove == null || raycastTarget == null) return;
            if (initializedWindows.Contains(windowToMove)) return;

            // Create a transparent overlay as a child of the raycast target
            // This ensures our drag handler is on top of any existing child elements
            GameObject overlay = new GameObject($"{windowName}DragOverlay");
            overlay.transform.SetParent(raycastTarget.transform, false);

            // Add RectTransform and stretch to fill parent
            RectTransform overlayRect = overlay.AddComponent<RectTransform>();
            overlayRect.anchorMin = Vector2.zero;
            overlayRect.anchorMax = Vector2.one;
            overlayRect.offsetMin = Vector2.zero;
            overlayRect.offsetMax = Vector2.zero;

            // Make it the last sibling so it renders on top and catches events first
            overlay.transform.SetAsLastSibling();

            // Add transparent Image for raycast
            Image overlayImage = overlay.AddComponent<Image>();
            overlayImage.color = new Color(0, 0, 0, 0); // Fully transparent
            overlayImage.raycastTarget = true;

            // Add the drag handler to the overlay, configured to move the parent window
            var handler = overlay.AddComponent<WindowDragHandler>();
            handler.InitializeWithTarget(windowName, posX, posY, windowToMove.GetComponent<RectTransform>());
            Debug.Log($"DraggableWindows: Setup drag handler for {windowName} (overlay on {raycastTarget.name})");

            initializedWindows.Add(windowToMove);
        }
    }

    /// <summary>
    /// Component attached to each draggable window that handles drag events.
    /// Uses delta-based movement to work with any anchor/pivot configuration.
    /// </summary>
    public class WindowDragHandler : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
    {
        private string windowName;
        private ConfigEntry<float> posXConfig;
        private ConfigEntry<float> posYConfig;
        private RectTransform rectTransform;
        private Canvas parentCanvas;
        private bool isDragging;

        public void Initialize(string name, ConfigEntry<float> posX, ConfigEntry<float> posY)
        {
            InitializeWithTarget(name, posX, posY, null);
        }

        /// <summary>
        /// Initialize with an optional target RectTransform to move.
        /// If targetRect is null, moves the GameObject this component is attached to.
        /// </summary>
        public void InitializeWithTarget(string name, ConfigEntry<float> posX, ConfigEntry<float> posY, RectTransform targetRect)
        {
            windowName = name;
            posXConfig = posX;
            posYConfig = posY;

            // Use the provided target, or fall back to our own RectTransform
            rectTransform = targetRect ?? GetComponent<RectTransform>();

            // Find parent canvas (from the target we're moving)
            parentCanvas = rectTransform.GetComponentInParent<Canvas>();

            // Apply saved position if valid
            if (!float.IsNaN(posX.Value) && !float.IsNaN(posY.Value))
            {
                rectTransform.anchoredPosition = new Vector2(posX.Value, posY.Value);
                Debug.Log($"DraggableWindows: Restored {windowName} position to ({posX.Value}, {posY.Value})");
            }

            // Ensure this GameObject can receive raycasts for drag events
            EnsureRaycastTarget();
        }

        /// <summary>
        /// Ensures this GameObject has an Image with raycastTarget = true so it can receive drag events.
        /// </summary>
        private void EnsureRaycastTarget()
        {
            var image = GetComponent<Image>();
            if (image != null)
            {
                // Existing Image - ensure raycastTarget is enabled
                image.raycastTarget = true;
                Debug.Log($"DraggableWindows: {windowName} - enabled raycastTarget on existing Image");
                return;
            }

            // Check if there's a background child we can use instead
            var bgImage = transform.Find("Background")?.GetComponent<Image>();
            if (bgImage == null)
            {
                bgImage = transform.Find("BG")?.GetComponent<Image>();
            }

            if (bgImage != null)
            {
                bgImage.raycastTarget = true;
                Debug.Log($"DraggableWindows: {windowName} - enabled raycastTarget on child background Image");
                return;
            }

            // No existing Image found - add a transparent raycast target
            image = gameObject.AddComponent<Image>();
            image.color = new Color(0, 0, 0, 0); // Fully transparent
            image.raycastTarget = true;
            Debug.Log($"DraggableWindows: {windowName} - added transparent raycast Image");
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            // Only handle left mouse button
            if (eventData.button != PointerEventData.InputButton.Left) return;

            isDragging = true;
            GameData.DraggingUIElement = true;
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (!isDragging) return;

            // Use delta-based movement - this works regardless of anchor/pivot configuration
            // eventData.delta is in screen pixels, need to convert to canvas scale
            if (parentCanvas != null)
            {
                float scaleFactor = parentCanvas.scaleFactor;
                rectTransform.anchoredPosition += eventData.delta / scaleFactor;
            }
            else
            {
                // Fallback if no canvas found
                rectTransform.anchoredPosition += eventData.delta;
            }
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if (!isDragging) return;

            isDragging = false;
            GameData.DraggingUIElement = false;

            // Save position
            posXConfig.Value = rectTransform.anchoredPosition.x;
            posYConfig.Value = rectTransform.anchoredPosition.y;
            Plugin.Instance?.SaveConfig();

            Debug.Log($"DraggableWindows: Saved {windowName} position to ({posXConfig.Value}, {posYConfig.Value})");
        }
    }
}

